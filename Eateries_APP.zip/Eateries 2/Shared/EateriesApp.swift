//
//  EateriesApp.swift
//  Shared
//
//  Created by Yangxiaohu Cao on 11/5/21.
//

import SwiftUI

@main
struct EateriesApp: App {
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
  
    /// taking URls
    static var fileURL: URL {
        let fileName = "location.json"
        let fm = FileManager.default
        guard let documentDir = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "/") }
        let fileURL = documentDir.appendingPathComponent(fileName)
        return fileURL
    }
}
 
