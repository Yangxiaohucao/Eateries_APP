//
//  ContentView.swift
//  Shared
//
//  Created by Yangxiaohu Cao on 11/5/21.
//

import SwiftUI
import CoreData
import CoreLocation

///Displaying Navigation View
struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Resturant.rowOrder, ascending: true)],
        animation: .default)
    private var resturants: FetchedResults<Resturant>
    var body: some View {
        NavigationView{MasterView(resturants:resturants)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
