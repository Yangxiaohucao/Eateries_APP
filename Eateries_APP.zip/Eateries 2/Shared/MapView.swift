//
//  MapView.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 27/5/21.
//

import Foundation
import UIKit
import SwiftUI
import MapKit

///Creating and DIsplaying Map View
struct MapView: UIViewRepresentable {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var resturant: Resturant
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.showsUserLocation = true
        return mapView
    }
    ///update when theres new coordiantes
  func updateUIView(_ uiView: MKMapView, context: Context) {
    let coordinate = CLLocationCoordinate2D(latitude:Double (resturant.latitudeS) ?? -27.46, longitude:Double (resturant.longitudeS) ?? 153)
    uiView.setRegion(MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)),animated: true)
//    }
}

}
