//
//  MasterView.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 12/5/21.
//

import Foundation
import SwiftUI
import CoreData

/// setting the On move , on Delete and Row order Functions
struct MasterView: View {
    @Environment(\.managedObjectContext) private var viewContext
    var resturants: FetchedResults<Resturant>
   /// Move  on Delete and Edit button
    var body:some View{
    List {
            ForEach(resturants) {
                resturant in  RowView(resturant:resturant)
            }
       .onMove(perform:moveItem)
        .onDelete(perform: deleteItems)
    }.navigationTitle("My Eateries")
    .navigationBarItems(leading:
            EditButton(),trailing:Button(action:addItem){
            Label("", systemImage: "plus")
                Button(action:setvalues){
                    Label("Setvalues", systemImage: "")}
        })
    }
   
    ///init the defalut values
    func setvalues(){
        let Resturant1 = Resturant(context: viewContext)
        Resturant1.img = "noodlebar"
        Resturant1.name = "Noodle Bar"
        Resturant1.location = "Brisbane"
        Resturant1.notes = ""
        Resturant1.review = "Best food AND service EVER at the Peacock restaurant!!! Ryder attended to our every need with courtesy"
        
        let Resturant2 = Resturant(context: viewContext)
        Resturant2.img = "bar"
        Resturant2.name = "Main Street Bar and Eatery"
        Resturant2.location = "New York"
        Resturant2.notes = ""
        Resturant2.review = "Very good choice i visited that restaurant with my friends. I am very happy for this choice. Good food"
        
        let Resturant3 = Resturant(context: viewContext)
        Resturant3.img = "kitchen"
        Resturant3.name = "Wild Spice Kitchen"
        Resturant3.location = "257 Annerley Rd, Annerley QLD"
        Resturant3.notes = ""
        Resturant3.review = "Great Spectacular food. Everything here was excellent"
        
        let Resturant4 = Resturant(context: viewContext)
        Resturant4.img = "sidestreet"
        Resturant4.name = "Side Street Kitchen"
        Resturant4.location = "417 Beaudesert Rd, Moorooka QLD"
        Resturant4.notes = ""
        Resturant4.review = "Amazing Dinner and 1st Class Service My wife and I had an amazing dinner here. "
        
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }

    private func moveItem(from source:IndexSet, to destination:Int) {
        if source.first! > destination{
            resturants[source.first!].rowOrder = resturants[destination].rowOrder-1
            for i in destination...resturants.count-1{
                resturants[i].rowOrder = resturants[i].rowOrder + 1
            }
        }
        if source.first! < destination {
            resturants[source.first!].rowOrder = resturants[destination-1].rowOrder+1
            for i in 0...destination-1{
                resturants[i].rowOrder = resturants[i].rowOrder-1
            }
        }
        
            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }

    private func addItem() {
        withAnimation {
            let newResturant = Resturant(context: viewContext)
            newResturant.name = "New Resturant"
            newResturant.location = "New location"
            newResturant.notes = "New notes"

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { resturants[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}


