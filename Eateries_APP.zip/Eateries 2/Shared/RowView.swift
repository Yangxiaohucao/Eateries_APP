//
//  RowView.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 12/5/21.
//

import Foundation
import SwiftUI

///RowView that displays all items
struct RowView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var resturant: Resturant
    var body: some View {
        NavigationLink(
            destination: DetailView(resturant:resturant),
            label: {
                VStack{
                    Image(uiImage:resturant.imgString.load())
                        .scaledToFill()
                        .padding()
                    Image(resturant.imgString)
                        .scaledToFill()
                        .padding()
                    Text(resturant.nameString)
                    Text(resturant.locationString)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(resturant.notesString)
                }
            })
    }
}
