//
//  MapFrame.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 28/5/21.
//


import Foundation
import SwiftUI
import CoreLocation
import MapKit

///Struct for displaying the map
struct MapFrame:View{
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.editMode) var editMode
    @ObservedObject var resturant: Resturant
    @State var currentPosition = CLLocationCoordinate2D(latitude: -27.46, longitude:153 )
    
    ///Displaying Map View
    var body: some View {
        Text("Location")
            .font(.title)
            .frame(width: 300, height: 25)
            .border(Color.black)
            .background(Color.gray)
        MapView(resturant: resturant)
            .frame(width:300, height: 300, alignment: .center)
        
        ///Geolocation converting functions
        HStack{
            Text("Name")
            TextField("enter location name",text:$resturant.locationString,onCommit:{
                do {
                    try viewContext.save()
                } catch {
                    let nsError = error as NSError
                    fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                }
              let geoCoder = CLGeocoder()
                let region = CLCircularRegion(center:self.currentPosition,radius: 2_000_000,identifier:"\(self.currentPosition)")
                geoCoder.geocodeAddressString(self.resturant.locationString,in:region){(placemarks,error)in
                    guard let location = placemarks?.first?.location else{
                        print("Error location '\(self.resturant.locationString)':\(error.map{"\($0)"} ??  "<unknown error>")")
                        return
                    }
                    let position = location.coordinate
                    self.currentPosition.latitude = position.latitude
                    self.currentPosition.longitude = position.longitude
                    self.resturant.latitudeS = "\(position.latitude)"
                    self.resturant.longitudeS = "\(position.longitude)"
                }
            })
        }
        HStack{
            Text("latitude")
            TextField("enter latitude",text:$resturant.latitudeS ,onCommit:{
                do {
                    try viewContext.save()
                } catch {
                    let nsError = error as NSError
                    fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                }
                guard let latitude = CLLocationDegrees(self.resturant.latitudeS),
                      let longitude = CLLocationDegrees(self.resturant.latitudeS) else{
                print ("incorrect Coordinates")
                return
            }
            self.currentPosition.latitude = latitude
            self.currentPosition.longitude = longitude
            let geoCoder = CLGeocoder()
            let position = CLLocation(latitude: self.currentPosition.latitude, longitude: self.currentPosition.longitude)
            geoCoder.reverseGeocodeLocation(position){ (placemarks,error) in
                guard let placemark = placemarks?.first else{
                    print("Error \(self.currentPosition.latitude)/\(self.currentPosition.longitude): \(error.map{"\($0)"} ?? "unknown error")")
                    return
                }
                self.resturant.locationString = placemark.name ?? placemark.locality ?? placemark.subLocality ?? placemark.administrativeArea ?? placemark.country ??
                "<unknown Location>"
            }
        })
        }
        HStack{
            Text("longitude")
            TextField("enter longitude",text:$resturant.longitudeS,onCommit:{
                do {
                    try viewContext.save()
                } catch {
                    let nsError = error as NSError
                    fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                }
                guard let latitude = CLLocationDegrees(self.resturant.longitudeS),
                      let longitude = CLLocationDegrees(self.resturant.longitudeS) else{
                    print ("incorrect Coordinates")
                    return
                }
                self.currentPosition.latitude = latitude
                self.currentPosition.longitude = longitude
                let geoCoder = CLGeocoder()
                let position = CLLocation(latitude: self.currentPosition.latitude, longitude: self.currentPosition.longitude)
                geoCoder.reverseGeocodeLocation(position){ (placemarks,error) in
                    guard let placemark = placemarks?.first else{
                        print("Error \(self.currentPosition.latitude)/\(self.currentPosition.longitude): \(error.map{"\($0)"} ?? "unknown error")")
                        return
                    }
                    self.resturant.locationString = placemark.name ?? placemark.locality ?? placemark.subLocality ?? placemark.administrativeArea ?? placemark.country ??
                    "<unknown Location>"
                }
            })
        }
    }
    
}
