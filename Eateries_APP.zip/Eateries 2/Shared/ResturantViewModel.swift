//
//  ResturantViewModel.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 12/5/21.
//

import Foundation

//Define name string for none optional name object
extension Resturant{
   
    var nameString:String{
        get{name ?? ""}
        set{name = newValue}
    }
    var locationString:String{
        get{location ?? ""}
        set{location = newValue}
    }
    var notesString:String{
        get{notes ?? ""}
        set{notes = newValue}
    }
    
    var imgString:String{
        get{img ?? ""}
        set{img = newValue}
    }
    
    var reviewString:String{
        get{review ?? ""}
        set{review = newValue}
    }
    var titleString:String{
        get{title ?? ""}
        set{title = newValue}
    }
    
    var latitudeS:String{
        get{latitudecore ?? ""}
        set{latitudecore = newValue}
    }
    
    var longitudeS:String{
        get{longitudecore ?? ""}
        set{longitudecore = newValue}
    }
    

}
