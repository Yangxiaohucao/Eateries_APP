//
//  DetailView.swift
//  Eateries
//
//  Created by Yangxiaohu Cao on 13/5/21.
//

import Foundation
import SwiftUI
import CoreLocation
import MapKit


///Extension for converting string to URL
extension String{
    func load() -> UIImage{
    do{
        guard let url = URL(string: self)
        else{
            return UIImage()
        }

        let data:Data = try
        Data(contentsOf: url)
        return UIImage(data:data) ?? UIImage()
    }catch{
    }
        return UIImage()
    }
}

/// Edit mode  when the user press edit
struct DetailView: View {
   
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.editMode) var editMode
    @ObservedObject var resturant: Resturant
    var body: some View {
        if editMode?.wrappedValue == .active {
            ScrollView {
                Text("Enter image URL")
                TextField("Enter NEW", text:$resturant.imgString,onCommit:{
                    do {
                        try viewContext.save()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                })
                    .font(.caption)
                    .textFieldStyle(RoundedBorderTextFieldStyle());

                Text("Enter Name")
                TextField("Enter NEW", text:$resturant.nameString,onCommit:{
                    do {
                        try viewContext.save()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                })
                    .font(.caption)
                    .textFieldStyle(RoundedBorderTextFieldStyle());
                Text("Enter Location")
                TextField("Enter Location", text:$resturant.locationString,onCommit:{
                    do {
                        try viewContext.save()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                })
                    .font(.caption)
                    .textFieldStyle(RoundedBorderTextFieldStyle());
                Section(header:Text("Notes")){
                TextField("Enter Notes", text: $resturant.notesString,onCommit:{
                    do {
                        try viewContext.save()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
           
                })  .textFieldStyle(RoundedBorderTextFieldStyle());
                    VStack{
                       
                    }
                }
                Section(header:Text("Reviews")){
                    Button(action: {}, label: {
                        Text("add Review")
                    })
                TextField("Enter Reviews", text: $resturant.reviewString,onCommit:{
                    do {
                        try viewContext.save()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                })  .textFieldStyle(RoundedBorderTextFieldStyle());
                }
        }
        } else {
            ///Normal Scroll View
            ScrollView {
                Image(uiImage:resturant.imgString.load())
                Image(resturant.imgString)
                Text("Eateries Name:")
                    .font(.title)
                    .frame(width: 300, height: 25)
                    .border(Color.black)
                    .background(Color.gray)
                Text("\(resturant.nameString)")
                    .font(.system(size:14))
                    .padding()
                Text("Location:")
                    .font(.title)
                    .frame(width: 300, height: 25)
                    .border(Color.black)
                    .background(Color.gray)
                NavigationLink(resturant.locationString, destination: MapFrame(resturant:resturant))
                    .padding()
                Text("Resturant Reviews:")
                    .font(.title)
                    .frame(width: 300, height: 25)
                    .border(Color.black)
                    .background(Color.gray)
                Text("\(resturant.review ?? "")")
                    .font(.system(size:14))

            }.toolbar {
                EditButton()
            }
        }
    }
}

